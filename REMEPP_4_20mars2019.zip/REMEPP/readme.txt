Modèle REMEPP - Version 4.0
================================

Auteurs du modèle REMEPP :

Description : Le modèle REMEPP simule le remplissage de la plage en tant qu’espace de pratique de tourisme et de loisir

Plateforme : Le modèle REMEPP est développé sous la plateforme GAMA plateforme (http://gama-platform.org/), version 1.7.0

Matériel : Le modèle REMEPP est constitué du code gaml (fichier REMEPP_va.gaml) et de plusieurs fichiers shp (inclus dans le répertoire du modèle)

Installation : Installer et lancer GAMA 1.7,  puis faire un clic-droit dans l'onglet Models et sélectionner 'Open external files...', puis indiquer le chemin vers le fichier REMEPP_v4.gaml